abstract class InternetState {}

class InitialInternetState extends InternetState {}
class InternetGainedState extends InternetState {}
class InternetLostState extends InternetState {}