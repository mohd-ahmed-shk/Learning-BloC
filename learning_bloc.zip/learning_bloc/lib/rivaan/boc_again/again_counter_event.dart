abstract class AgainCounterEvent {}

class AgainCounterIncremented extends AgainCounterEvent {}

class AgainCounterDecremented extends AgainCounterEvent {}
